import { getStore } from '@netlify/blobs'
import type { Config } from '@netlify/functions'
import { currentSubscriber, errorResponse, json } from '../lib/security'
import { DEFAULT_LINKS } from '../lib/defaults'
import type { StreamLink } from '../lib/defaults'

export default async (req: Request) => {
  try {
    if (req.method !== 'GET') return json({ error: 'method' }, 405)
    const stored = (await getStore('config').get('links', { type: 'json' }).catch(() => null)) as StreamLink[] | null
    const links = stored ?? DEFAULT_LINKS
    const subscriber = await currentSubscriber(req)
    return json({
      subscribed: Boolean(subscriber),
      links: links.map(link => ({ id: link.id, name: link.name, note: link.note, url: subscriber ? link.url : null })),
    })
  } catch (error) {
    return errorResponse(error)
  }
}

export const config: Config = { path: '/api/links' }
