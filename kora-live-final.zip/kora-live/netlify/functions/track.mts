import { getStore } from '@netlify/blobs'
import type { Config } from '@netlify/functions'
import { clientIp, json, limited, readJson, sameOrigin } from '../lib/security'

export default async (req: Request) => {
  if (req.method !== 'POST') return new Response(null, { status: 405 })
  if (!sameOrigin(req)) return new Response(null, { status: 403 })
  const body = await readJson<{ id?: string }>(req, 500)
  const id = body?.id
  if (typeof id !== 'string' || !/^[A-Za-z0-9-]{8,64}$/.test(id)) return json({ error: 'bad' }, 400)
  if (await limited(`track:${clientIp(req)}`, 120, 60 * 60 * 1000)) return json({ ok: true })

  const stats = getStore('stats')
  const day = new Date().toISOString().slice(0, 10)
  const totals = ((await stats.get('totals', { type: 'json' }).catch(() => null)) as { visits: number; unique: number; daily: Record<string, number> } | null) ?? { visits: 0, unique: 0, daily: {} }
  totals.visits += 1
  totals.daily[day] = (totals.daily[day] || 0) + 1
  const seen = getStore('visitors')
  if (!(await seen.get(id).catch(() => null))) {
    await seen.set(id, '1')
    totals.unique += 1
  }
  await stats.setJSON('totals', totals)
  return json({ ok: true })
}

export const config: Config = { path: '/api/track' }
