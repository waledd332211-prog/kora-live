import { getStore } from '@netlify/blobs'
import type { Config } from '@netlify/functions'
import {
  PLANS, cleanText, clientIp, errorResponse, isAdmin, json, limited, randomCode, readJson,
  safeEqual, sameOrigin, setCookie, sign,
} from '../lib/security'
import type { SubRecord } from '../lib/security'
import { DEFAULT_LINKS } from '../lib/defaults'
import type { StreamLink } from '../lib/defaults'

type Revenue = { id: string; amount: number; source: 'subscription' | 'ads' | 'other'; note: string; date: string; ref?: string }
type Totals = { visits: number; unique: number; daily: Record<string, number> }

async function allSubs() {
  const store = getStore('subs')
  const { blobs } = await store.list()
  const records = await Promise.all(blobs.slice(0, 1000).map(blob => store.get(blob.key, { type: 'json' }).catch(() => null) as Promise<SubRecord | null>))
  const now = Date.now()
  return records
    .filter((record): record is SubRecord => Boolean(record))
    .map(record => (record.status === 'active' && record.expiresAt && record.expiresAt < now ? { ...record, status: 'expired' as const } : record))
    .sort((a, b) => b.createdAt - a.createdAt)
}

async function getRevenue() {
  return ((await getStore('config').get('revenue', { type: 'json' }).catch(() => null)) as Revenue[] | null) ?? []
}

function validLinks(input: unknown): StreamLink[] | null {
  if (!Array.isArray(input) || input.length > 40) return null
  const links: StreamLink[] = []
  for (const item of input) {
    const name = cleanText((item as StreamLink)?.name, 60)
    const note = cleanText((item as StreamLink)?.note, 120)
    const url = cleanText((item as StreamLink)?.url, 500)
    if (!name) return null
    try {
      const parsed = new URL(url)
      if (parsed.protocol !== 'https:') return null
    } catch { return null }
    links.push({ id: randomCode(6), name, url, note })
  }
  return links
}

export default async (req: Request) => {
  try {
    const path = new URL(req.url).pathname.replace(/^\/api\/admin\/?/, '')
    const ip = clientIp(req)

    if (req.method === 'POST' && !sameOrigin(req)) return json({ error: 'forbidden' }, 403)

    if (path === 'login' && req.method === 'POST') {
      if (await limited(`login:${ip}`, 8, 15 * 60 * 1000)) return json({ error: 'تم إيقاف المحاولات مؤقتاً. حاول بعد 15 دقيقة' }, 429)
      const configured = process.env.ADMIN_PASSWORD
      if (!configured) return json({ error: 'ADMIN_PASSWORD غير مضبوط على الخادم' }, 500)
      const body = await readJson<{ password?: string }>(req, 1000)
      const password = typeof body?.password === 'string' ? body.password.slice(0, 200) : ''
      if (password && safeEqual(password, configured)) {
        const token = sign({ r: 'admin' }, 6 * 3600 * 1000)
        return json({ ok: true }, 200, { 'Set-Cookie': setCookie('kl_admin', token, 6 * 3600) })
      }
      await new Promise(resolve => setTimeout(resolve, 800))
      return json({ error: 'رمز المرور غير صحيح' }, 401)
    }

    if (path === 'logout' && req.method === 'POST') {
      return json({ ok: true }, 200, { 'Set-Cookie': setCookie('kl_admin', '', 0) })
    }

    if (!isAdmin(req)) return json({ error: 'unauthorized' }, 401)

    const cfg = getStore('config')

    if (path === 'me') return json({ ok: true })

    if (path === 'stats' && req.method === 'GET') {
      const totals = ((await getStore('stats').get('totals', { type: 'json' }).catch(() => null)) as Totals | null) ?? { visits: 0, unique: 0, daily: {} }
      const subs = await allSubs()
      const revenue = await getRevenue()
      const members = (await getStore('members').list()).blobs.length
      const days = Array.from({ length: 14 }, (_, index) => new Date(Date.now() - (13 - index) * 86400000).toISOString().slice(0, 10))
      const sum = (source: Revenue['source']) => revenue.filter(item => item.source === source).reduce((total, item) => total + item.amount, 0)
      return json({
        visits: totals.visits,
        unique: totals.unique,
        daily: days.map(day => ({ day, visits: totals.daily[day] || 0 })),
        members,
        subscribers: {
          active: subs.filter(item => item.status === 'active').length,
          pending: subs.filter(item => item.status === 'pending').length,
          total: subs.length,
          monthly: subs.filter(item => item.status === 'active' && item.plan === 'monthly').length,
          yearly: subs.filter(item => item.status === 'active' && item.plan === 'yearly').length,
        },
        revenue: { total: sum('subscription') + sum('ads') + sum('other'), subscriptions: sum('subscription'), ads: sum('ads'), other: sum('other'), recent: revenue.slice(-15).reverse() },
      })
    }

    if (path === 'subscribers' && req.method === 'GET') return json({ subscribers: await allSubs() })

    if ((path === 'subscribers/activate' || path === 'subscribers/deactivate') && req.method === 'POST') {
      const body = await readJson<{ ref?: string }>(req, 500)
      const ref = cleanText(body?.ref, 12)
      const store = getStore('subs')
      const record = ref ? ((await store.get(ref, { type: 'json' }).catch(() => null)) as SubRecord | null) : null
      if (!record) return json({ error: 'غير موجود' }, 404)
      if (path.endsWith('deactivate')) {
        record.status = 'cancelled'
        await store.setJSON(ref, record)
        return json({ ok: true })
      }
      const now = Date.now()
      const base = record.status === 'active' && record.expiresAt && record.expiresAt > now ? record.expiresAt : now
      record.status = 'active'
      record.startedAt = record.startedAt ?? now
      record.expiresAt = base + PLANS[record.plan].days * 86400000
      if (!record.accessCode) {
        record.accessCode = randomCode(10)
        await getStore('codes').set(record.accessCode, record.ref)
      }
      await store.setJSON(ref, record)
      const revenue = await getRevenue()
      revenue.push({ id: randomCode(6), amount: record.price, source: 'subscription', note: `اشتراك ${PLANS[record.plan].label} - ${record.name}`, date: new Date().toISOString().slice(0, 10), ref: record.ref })
      await cfg.setJSON('revenue', revenue)
      return json({ ok: true, accessCode: record.accessCode, expiresAt: record.expiresAt })
    }

    if (path === 'links' && req.method === 'GET') {
      const stored = (await cfg.get('links', { type: 'json' }).catch(() => null)) as StreamLink[] | null
      return json({ links: stored ?? DEFAULT_LINKS })
    }
    if (path === 'links' && req.method === 'POST') {
      const body = await readJson<{ links?: unknown }>(req, 40000)
      const links = validLinks(body?.links)
      if (!links) return json({ error: 'تأكد أن كل رابط يبدأ بـ https وأن لكل رابط اسماً' }, 400)
      await cfg.setJSON('links', links)
      return json({ ok: true, links })
    }

    if (path === 'revenue' && req.method === 'POST') {
      const body = await readJson<{ amount?: number; note?: string; source?: string }>(req, 1000)
      const amount = Number(body?.amount)
      if (!Number.isFinite(amount) || amount <= 0 || amount > 10_000_000) return json({ error: 'مبلغ غير صحيح' }, 400)
      const source = body?.source === 'ads' ? 'ads' : 'other'
      const revenue = await getRevenue()
      revenue.push({ id: randomCode(6), amount, source, note: cleanText(body?.note, 120), date: new Date().toISOString().slice(0, 10) })
      await cfg.setJSON('revenue', revenue)
      return json({ ok: true })
    }

    if (path === 'settings' && req.method === 'GET') {
      return json({ settings: ((await cfg.get('settings', { type: 'json' }).catch(() => null)) as Record<string, string> | null) ?? { paymentInstructions: '' } })
    }
    if (path === 'settings' && req.method === 'POST') {
      const body = await readJson<{ paymentInstructions?: string }>(req, 3000)
      await cfg.setJSON('settings', { paymentInstructions: cleanText(body?.paymentInstructions, 1000) })
      return json({ ok: true })
    }

    return json({ error: 'not found' }, 404)
  } catch (error) {
    return errorResponse(error)
  }
}

export const config: Config = { path: '/api/admin/*' }
