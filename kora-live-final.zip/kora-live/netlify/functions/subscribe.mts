import { createHash, randomBytes } from 'node:crypto'
import { getStore } from '@netlify/blobs'
import type { Config } from '@netlify/functions'
import {
  PLANS, cleanText, clientIp, currentSubscriber, emailOk, errorResponse, json, limited,
  notifyOwner, phoneOk, randomCode, readJson, sameOrigin, setCookie, sign,
} from '../lib/security'
import type { PlanId, SubRecord } from '../lib/security'

const DEFAULT_INSTRUCTIONS = 'سيتواصل معك المالك لإتمام الدفع. احتفظ برقم المرجع.'

export default async (req: Request) => {
  try {
    const path = new URL(req.url).pathname.replace(/^\/api\/sub\/?/, '')
    const ip = clientIp(req)

    if (path === 'status' && req.method === 'GET') {
      const sub = await currentSubscriber(req)
      return json({ subscribed: Boolean(sub), plan: sub?.plan ?? null, expiresAt: sub?.expiresAt ?? null })
    }

    if (req.method !== 'POST') return json({ error: 'method' }, 405)
    if (!sameOrigin(req)) return json({ error: 'forbidden' }, 403)

    if (path === 'logout') {
      return json({ ok: true }, 200, { 'Set-Cookie': setCookie('kl_sub', '', 0) })
    }

    const body = await readJson<Record<string, unknown>>(req)
    if (!body) return json({ error: 'طلب غير صالح' }, 400)

    if (path === 'request') {
      if (await limited(`subreq:${ip}`, 5, 60 * 60 * 1000)) return json({ error: 'محاولات كثيرة، حاول لاحقاً' }, 429)
      const plan = body.plan as PlanId
      if (!(plan in PLANS)) return json({ error: 'الباقة غير صحيحة' }, 400)
      const name = cleanText(body.name, 60)
      const email = cleanText(body.email, 120).toLowerCase()
      const phone = cleanText(body.phone, 20)
      if (name.length < 2) return json({ error: 'اكتب اسمك' }, 400)
      if (!email && !phone) return json({ error: 'أدخل البريد أو رقم الجوال' }, 400)
      if (email && !emailOk(email)) return json({ error: 'البريد الإلكتروني غير صحيح' }, 400)
      if (phone && !phoneOk(phone)) return json({ error: 'رقم الجوال غير صحيح' }, 400)
      const ref = randomCode(8)
      const record: SubRecord = { ref, plan, price: PLANS[plan].price, name, email, phone, status: 'pending', createdAt: Date.now() }
      await getStore('subs').setJSON(ref, record)
      await notifyOwner(`طلب اشتراك جديد (${PLANS[plan].label} - ${PLANS[plan].price} ريال)\nالاسم: ${name}\nالبريد: ${email || '-'}\nالجوال: ${phone || '-'}\nالمرجع: ${ref}`)
      const settings = ((await getStore('config').get('settings', { type: 'json' }).catch(() => null)) as { paymentInstructions?: string } | null) ?? {}
      return json({ ref, price: PLANS[plan].price, instructions: settings.paymentInstructions || DEFAULT_INSTRUCTIONS })
    }

    if (path === 'redeem') {
      if (await limited(`redeem:${ip}`, 10, 15 * 60 * 1000)) return json({ error: 'محاولات كثيرة، حاول بعد 15 دقيقة' }, 429)
      const code = cleanText(body.code, 20).toUpperCase().replace(/\s/g, '')
      if (code.length < 8) return json({ error: 'رمز غير صحيح' }, 400)
      const ref = (await getStore('codes').get(code).catch(() => null)) as string | null
      const record = ref ? ((await getStore('subs').get(ref, { type: 'json' }).catch(() => null)) as SubRecord | null) : null
      if (!record || record.status !== 'active' || !record.expiresAt || record.expiresAt < Date.now()) {
        return json({ error: 'الرمز غير صحيح أو منتهي' }, 400)
      }
      const maxAge = Math.min(Math.floor((record.expiresAt - Date.now()) / 1000), 400 * 24 * 3600)
      const token = sign({ r: 'sub', id: record.ref }, maxAge * 1000)
      return json({ ok: true, plan: record.plan, expiresAt: record.expiresAt }, 200, { 'Set-Cookie': setCookie('kl_sub', token, maxAge) })
    }

    if (path === 'register') {
      if (await limited(`register:${ip}`, 10, 60 * 60 * 1000)) return json({ error: 'محاولات كثيرة' }, 429)
      const email = cleanText(body.email, 120).toLowerCase()
      const phone = cleanText(body.phone, 20)
      if (!email && !phone) return json({ error: 'أدخل البريد أو رقم الجوال' }, 400)
      if (email && !emailOk(email)) return json({ error: 'البريد الإلكتروني غير صحيح' }, 400)
      if (phone && !phoneOk(phone)) return json({ error: 'رقم الجوال غير صحيح' }, 400)
      const key = createHash('sha256').update(email || phone.replace(/[\s-]/g, '')).digest('hex').slice(0, 32)
      await getStore('members').setJSON(key, { email, phone, createdAt: Date.now(), id: randomBytes(4).toString('hex') })
      return json({ ok: true })
    }

    return json({ error: 'not found' }, 404)
  } catch (error) {
    return errorResponse(error)
  }
}

export const config: Config = { path: '/api/sub/*' }
