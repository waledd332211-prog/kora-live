import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { getStore } from '@netlify/blobs'

export const PLANS = {
  monthly: { price: 15, days: 30, label: 'شهري' },
  yearly: { price: 80, days: 365, label: 'سنوي' },
} as const
export type PlanId = keyof typeof PLANS

export type SubRecord = {
  ref: string
  plan: PlanId
  price: number
  name: string
  email: string
  phone: string
  status: 'pending' | 'active' | 'expired' | 'cancelled'
  createdAt: number
  startedAt?: number
  expiresAt?: number
  accessCode?: string
}

const SECURITY_HEADERS = {
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'Content-Type': 'application/json; charset=utf-8',
}

function sessionSecret() {
  const s = process.env.SESSION_SECRET
  if (!s || s.length < 24) throw new Error('SESSION_SECRET غير مضبوط أو أقصر من 24 حرفاً')
  return s
}

export function sign(payload: Record<string, unknown>, ttlMs: number) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + ttlMs })).toString('base64url')
  const sig = createHmac('sha256', sessionSecret()).update(body).digest('base64url')
  return `${body}.${sig}`
}

export function verify(token: string | null | undefined): Record<string, unknown> | null {
  if (!token) return null
  const [body, sig] = token.split('.')
  if (!body || !sig) return null
  const good = createHmac('sha256', sessionSecret()).update(body).digest('base64url')
  if (sig.length !== good.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as Record<string, unknown>
    return typeof payload.exp === 'number' && payload.exp > Date.now() ? payload : null
  } catch {
    return null
  }
}

export function safeEqual(a: string, b: string) {
  const x = createHash('sha256').update(a).digest()
  const y = createHash('sha256').update(b).digest()
  return timingSafeEqual(x, y)
}

export function getCookie(req: Request, name: string) {
  const header = req.headers.get('cookie') || ''
  for (const part of header.split(';')) {
    const [key, ...rest] = part.trim().split('=')
    if (key === name) return rest.join('=')
  }
  return null
}

export function setCookie(name: string, value: string, maxAgeSec: number) {
  return `${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAgeSec}`
}

export function json(data: unknown, status = 200, extra: Record<string, string | string[]> = {}) {
  const headers = new Headers(SECURITY_HEADERS)
  for (const [key, value] of Object.entries(extra)) {
    if (Array.isArray(value)) value.forEach(v => headers.append(key, v))
    else headers.set(key, value)
  }
  return new Response(JSON.stringify(data), { status, headers })
}

export function clientIp(req: Request) {
  return req.headers.get('x-nf-client-connection-ip') || req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown'
}

/** يرجع true إذا تجاوز العميل الحد المسموح (يُسجَّل كل استدعاء). */
export async function limited(key: string, max: number, windowMs: number) {
  const store = getStore('ratelimit')
  const safeKey = createHash('sha256').update(key).digest('hex').slice(0, 40)
  const now = Date.now()
  const entry = (await store.get(safeKey, { type: 'json' }).catch(() => null)) as { count: number; reset: number } | null
  const current = entry && entry.reset > now ? entry : { count: 0, reset: now + windowMs }
  current.count += 1
  await store.setJSON(safeKey, current).catch(() => undefined)
  return current.count > max
}

export async function readJson<T = Record<string, unknown>>(req: Request, maxBytes = 20000): Promise<T | null> {
  if (!(req.headers.get('content-type') || '').includes('application/json')) return null
  const text = await req.text()
  if (text.length > maxBytes) return null
  try { return JSON.parse(text) as T } catch { return null }
}

/** حماية CSRF: يجب أن يكون الطلب من نفس الموقع. */
export function sameOrigin(req: Request) {
  const origin = req.headers.get('origin')
  if (!origin) return true
  try { return new URL(origin).host === new URL(req.url).host } catch { return false }
}

export function isAdmin(req: Request) {
  const payload = verify(getCookie(req, 'kl_admin'))
  return payload?.r === 'admin'
}

export async function currentSubscriber(req: Request): Promise<SubRecord | null> {
  const payload = verify(getCookie(req, 'kl_sub'))
  if (!payload || payload.r !== 'sub' || typeof payload.id !== 'string') return null
  const record = (await getStore('subs').get(payload.id, { type: 'json' }).catch(() => null)) as SubRecord | null
  if (!record || record.status !== 'active' || !record.expiresAt || record.expiresAt < Date.now()) return null
  return record
}

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
export function randomCode(length: number) {
  const bytes = randomBytes(length)
  return Array.from(bytes, byte => CODE_ALPHABET[byte % CODE_ALPHABET.length]).join('')
}

export function cleanText(value: unknown, max: number) {
  return typeof value === 'string' ? value.replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max) : ''
}

export const emailOk = (value: string) => /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(value)
export const phoneOk = (value: string) => /^\+?\d{8,15}$/.test(value.replace(/[\s-]/g, ''))

export async function notifyOwner(text: string) {
  const url = process.env.NOTIFY_WEBHOOK_URL
  if (!url || !url.startsWith('https://')) return
  try {
    await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, content: text }), signal: AbortSignal.timeout(5000) })
  } catch { /* لا نكسر الطلب بسبب فشل التنبيه */ }
}

export function errorResponse(error: unknown) {
  const message = error instanceof Error ? error.message : 'خطأ غير متوقع'
  return json({ error: message.includes('SESSION_SECRET') ? 'إعداد الخادم غير مكتمل: SESSION_SECRET' : 'تعذر تنفيذ الطلب' }, 500)
}
