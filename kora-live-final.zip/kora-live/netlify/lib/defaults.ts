export type StreamLink = { id: string; name: string; url: string; note: string }

// روابط رسمية فقط. يستطيع المالك تعديلها من لوحة المالك.
export const DEFAULT_LINKS: StreamLink[] = [
  { id: 'bein', name: 'beIN SPORTS (رسمي)', url: 'https://www.beinsports.com', note: 'الناقل الرسمي لأغلب الدوريات' },
  { id: 'shahid', name: 'شاهد (رسمي)', url: 'https://shahid.mbc.net', note: 'منصة MBC الرسمية' },
]
