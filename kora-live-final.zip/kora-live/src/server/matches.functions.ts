import { createServerFn } from '@tanstack/react-start'
import { loadMatchDetails, loadMatchFeed, loadResultsFeed, loadStandings } from './matches.server'
import { leagueDefinitions } from '../lib/matches'

function validateTimeZone(input: { timeZone: string }) {
  if (!input || typeof input.timeZone !== 'string' || input.timeZone.length > 80) {
    throw new Error('المنطقة الزمنية غير صالحة')
  }
  try {
    new Intl.DateTimeFormat('ar', { timeZone: input.timeZone }).format()
  } catch {
    throw new Error('المنطقة الزمنية غير صالحة')
  }
  return { timeZone: input.timeZone }
}

export const getMatchFeed = createServerFn({ method: 'GET' })
  .inputValidator(validateTimeZone)
  .handler(({ data }) => loadMatchFeed(data.timeZone))

export const getResultsFeed = createServerFn({ method: 'GET' })
  .inputValidator(validateTimeZone)
  .handler(({ data }) => loadResultsFeed(data.timeZone))

export const getMatchDetails = createServerFn({ method: 'GET' })
  .inputValidator((input: { matchId: string; teamId1: string; teamId2: string }) => {
    if (!input || typeof input.matchId !== 'string' || !/^[a-z0-9.]{3,30}:\d{1,12}$/.test(input.matchId)) {
      throw new Error('مباراة غير صالحة')
    }
    const clean = (value: unknown) => (typeof value === 'string' && /^\d{1,10}$/.test(value) ? value : '')
    return { matchId: input.matchId, teamId1: clean(input.teamId1), teamId2: clean(input.teamId2) }
  })
  .handler(({ data }) => loadMatchDetails(data.matchId, data.teamId1, data.teamId2))

export const getStandings = createServerFn({ method: 'GET' })
  .inputValidator((input: { leagueId: string }) => {
    if (!input || typeof input.leagueId !== 'string' || !leagueDefinitions.some(l => l.id === input.leagueId)) {
      throw new Error('الدوري غير صالح')
    }
    return { leagueId: input.leagueId }
  })
  .handler(({ data }) => loadStandings(data.leagueId))
