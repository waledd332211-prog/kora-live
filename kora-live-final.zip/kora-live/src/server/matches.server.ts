import { leagueDefinitions, isCurrentMatch } from '../lib/matches'
import type { LineupPlayer, Match, MatchDetails, MatchEvent, MatchFeed, ResultsFeed, StandingEntry, StandingsFeed, StatRow, TeamLineup } from '../lib/matches'

type ProviderStatus = {
  displayClock?: string
  type?: { name?: string; state?: string; completed?: boolean }
}
type ProviderCompetitor = {
  homeAway?: string
  score?: string | { displayValue?: string }
  team?: { id?: string; displayName?: string; abbreviation?: string; logo?: string }
}
type ProviderEvent = {
  id?: string
  date?: string
  week?: { number?: number }
  status?: ProviderStatus
  competitions?: {
    date?: string
    timeValid?: boolean
    status?: ProviderStatus
    competitors?: ProviderCompetitor[]
    broadcasts?: { names?: string[] }[]
  }[]
}
type Scoreboard = {
  events: ProviderEvent[]
  leagues?: { calendar?: string[] }[]
}

const teamNames: Record<string, string> = {
  'Al Nassr': 'النصر', 'Al Hilal': 'الهلال', 'Al Ittihad': 'الاتحاد',
  'Al Ahli': 'الأهلي', 'Al Shabab': 'الشباب', 'Al Ettifaq': 'الاتفاق',
  'Al Taawoun': 'التعاون', 'Al Fateh': 'الفتح', 'Al Fayha': 'الفيحاء',
  'Al Riyadh': 'الرياض', 'Al Khaleej': 'الخليج', 'Al Qadsiah': 'القادسية',
  'Al Qadisiyah': 'القادسية', 'Al Kholood': 'الخلود', 'Al Okhdood': 'الأخدود',
  'Al Raed': 'الرائد', 'Al Wehda': 'الوحدة', 'Al Hazem': 'الحزم',
  'Al Najma': 'النجمة', 'Damac': 'ضمك', 'NEOM': 'نيوم', 'Neom SC': 'نيوم',
  'Abha': 'أبها', 'Al Adalah': 'العدالة', 'Al Tai': 'الطائي',
  'Real Madrid': 'ريال مدريد', 'Barcelona': 'برشلونة', 'Atlético Madrid': 'أتلتيكو مدريد',
  'Atletico Madrid': 'أتلتيكو مدريد', 'Athletic Club': 'أتلتيك بلباو',
  'Real Sociedad': 'ريال سوسيداد', 'Real Betis': 'ريال بيتيس', 'Sevilla': 'إشبيلية',
  'Valencia': 'فالنسيا', 'Villarreal': 'فياريال', 'Girona': 'جيرونا',
  'Espanyol': 'إسبانيول', 'Málaga': 'مالقة', 'Malaga': 'مالقة',
  'Celta Vigo': 'سيلتا فيغو', 'Osasuna': 'أوساسونا', 'Mallorca': 'مايوركا',
  'Getafe': 'خيتافي', 'Rayo Vallecano': 'رايو فايكانو', 'Alavés': 'ألافيس',
  'Elche': 'إلتشي', 'Levante': 'ليفانتي', 'Real Oviedo': 'ريال أوفييدو',
  'Las Palmas': 'لاس بالماس', 'Real Valladolid': 'بلد الوليد', 'Leganés': 'ليغانيس',
  'Granada': 'غرناطة', 'Almería': 'ألميريا', 'Racing Santander': 'راسينغ سانتاندير',
  'Arsenal': 'أرسنال', 'Liverpool': 'ليفربول', 'Manchester City': 'مانشستر سيتي',
  'Manchester United': 'مانشستر يونايتد', 'Chelsea': 'تشيلسي',
  'Tottenham Hotspur': 'توتنهام', 'Newcastle United': 'نيوكاسل يونايتد',
  'Aston Villa': 'أستون فيلا', 'Brighton & Hove Albion': 'برايتون',
  'West Ham United': 'وست هام', 'Crystal Palace': 'كريستال بالاس',
  'Nottingham Forest': 'نوتنغهام فورست', 'Fulham': 'فولهام', 'Everton': 'إيفرتون',
  'Brentford': 'برينتفورد', 'Bournemouth': 'بورنموث',
  'Wolverhampton Wanderers': 'وولفرهامبتون', 'Leeds United': 'ليدز يونايتد',
  'Burnley': 'بيرنلي', 'Sunderland': 'سندرلاند', 'Southampton': 'ساوثهامبتون',
  'Leicester City': 'ليستر سيتي', 'Ipswich Town': 'إيبسويتش تاون',
  // إيطاليا
  'Inter Milan': 'إنتر ميلان', 'Internazionale': 'إنتر ميلان', 'AC Milan': 'ميلان', 'Milan': 'ميلان',
  'Juventus': 'يوفنتوس', 'Napoli': 'نابولي', 'AS Roma': 'روما', 'Roma': 'روما',
  'Lazio': 'لاتسيو', 'Atalanta': 'أتالانتا', 'Fiorentina': 'فيورنتينا', 'Torino': 'تورينو',
  'Bologna': 'بولونيا', 'Udinese': 'أودينيزي', 'Genoa': 'جنوى', 'Cagliari': 'كالياري',
  'Monza': 'مونزا', 'Empoli': 'إمبولي', 'Lecce': 'ليتشي', 'Sassuolo': 'ساسولو',
  'Verona': 'فيرونا', 'Parma': 'بارما', 'Como': 'كومو', 'Venezia': 'فينيسيا',
  // ألمانيا
  'Bayern Munich': 'بايرن ميونخ', 'Bayern München': 'بايرن ميونخ', 'Borussia Dortmund': 'دورتموند',
  'RB Leipzig': 'لايبزيغ', 'Bayer Leverkusen': 'باير ليفركوزن', 'Eintracht Frankfurt': 'فرانكفورت',
  'VfB Stuttgart': 'شتوتغارت', 'Wolfsburg': 'فولفسبورغ', 'Borussia Mönchengladbach': 'غلادباخ',
  'Hoffenheim': 'هوفنهايم', 'Freiburg': 'فرايبورغ', 'Werder Bremen': 'فيردر بريمن',
  'Augsburg': 'آوغسبورغ', 'Mainz': 'ماينز', 'Union Berlin': 'يونيون برلين',
  'Heidenheim': 'هايدنهايم', 'Bochum': 'بوخوم', 'St. Pauli': 'سانت باولي',
  // فرنسا
  'Paris Saint-Germain': 'باريس سان جيرمان', 'PSG': 'باريس سان جيرمان', 'Marseille': 'مارسيليا',
  'Olympique de Marseille': 'مارسيليا', 'Lyon': 'ليون', 'Olympique Lyonnais': 'ليون',
  'Monaco': 'موناكو', 'AS Monaco': 'موناكو', 'Lille': 'ليل', 'Nice': 'نيس',
  'Rennes': 'رين', 'Lens': 'لانس', 'Strasbourg': 'ستراسبورغ', 'Nantes': 'نانت',
  'Toulouse': 'تولوز', 'Reims': 'ريمس', 'Montpellier': 'مونبلييه', 'Brest': 'بريست',
  // أخرى شائعة
  'Ajax': 'أياكس', 'PSV Eindhoven': 'بي إس في', 'Feyenoord': 'فاينورد',
  'Porto': 'بورتو', 'Benfica': 'بنفيكا', 'Sporting CP': 'سبورتنغ لشبونة',
  'Galatasaray': 'غلطة سراي', 'Fenerbahce': 'فنربخشة', 'Besiktas': 'بشكتاش',
  'Al Ahly': 'الأهلي المصري', 'Zamalek': 'الزمالك', 'Pyramids': 'بيراميدز',
}

function safeLogo(logo?: string) {
  return logo && /^https:\/\/a\.espncdn\.com\/i\/teamlogos\/[a-zA-Z0-9/_.,-]+$/.test(logo) ? logo : null
}

function scoreValue(score: ProviderCompetitor['score']) {
  return typeof score === 'string' ? score : score?.displayValue || '0'
}

// استبعاد مباريات النساء وفرق الفئات السنية والاحتياط
function isExcludedTeam(name: string) {
  return /\b(women|ladies|youth|reserves|academy)\b/i.test(name) || /\bU-?(1[5-9]|2[0-3])\b/i.test(name) || /\bW\b/.test(name)
}

// ---------- ذاكرة مؤقتة قصيرة حتى لا نضغط على مصدر البيانات ----------
const cache = new Map<string, { at: number; value: Promise<unknown> }>()
function cached<T>(key: string, ttl: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key)
  if (hit && Date.now() - hit.at < ttl) return hit.value as Promise<T>
  const value = load()
  cache.set(key, { at: Date.now(), value })
  value.catch(() => { if (cache.get(key)?.value === value) cache.delete(key) })
  if (cache.size > 500) {
    const oldest = [...cache.entries()].sort((x, y) => x[1].at - y[1].at)[0]
    if (oldest) cache.delete(oldest[0])
  }
  return value
}

type CommonParts = { home: ProviderCompetitor; away: ProviderCompetitor; kickoff: string; kickoffMs: number }
function readTeams(event: ProviderEvent): CommonParts | null {
  const competition = event.competitions?.[0]
  const competitors = competition?.competitors || []
  const home = competitors.find(competitor => competitor.homeAway === 'home') || competitors[0]
  const away = competitors.find(competitor => competitor.homeAway === 'away') || competitors[1]
  const kickoff = competition?.date || event.date
  if (!home?.team?.displayName || !away?.team?.displayName || !kickoff || !Number.isFinite(Date.parse(kickoff))) return null
  if (isExcludedTeam(home.team.displayName) || isExcludedTeam(away.team.displayName)) return null
  return { home, away, kickoff, kickoffMs: Date.parse(kickoff) }
}

function baseMatch(event: ProviderEvent, league: (typeof leagueDefinitions)[number], parts: CommonParts) {
  const competition = event.competitions?.[0]
  const { home, away, kickoff } = parts
  return {
    id: `${league.id}:${event.id}`,
    league: league.name,
    filter: league.filter,
    team1: teamNames[home.team?.displayName || ''] || home.team?.displayName || '',
    team2: teamNames[away.team?.displayName || ''] || away.team?.displayName || '',
    logo1: safeLogo(home.team?.logo), logo2: safeLogo(away.team?.logo),
    initials1: home.team?.abbreviation || '', initials2: away.team?.abbreviation || '',
    kickoff, timeConfirmed: competition?.timeValid !== false,
    channels: [...new Set((competition?.broadcasts || []).flatMap(broadcast => broadcast.names || []))],
    leagueId: league.id, eventId: String(event.id),
    teamId1: home.team?.id || '', teamId2: away.team?.id || '',
  }
}

function normalizeMatch(event: ProviderEvent, league: (typeof leagueDefinitions)[number], now: number): Match | null {
  const competition = event.competitions?.[0]
  const status = competition?.status || event.status
  const state = status?.type?.state
  const statusName = status?.type?.name || ''
  if (!event.id || !competition || !['pre', 'in'].includes(state || '')) return null
  if (status?.type?.completed || /FINAL|FULL_TIME|END|CANCEL|POSTPON|SUSPEND|ABANDON|ABORT/.test(statusName)) return null
  const parts = readTeams(event)
  if (!parts) return null
  if (parts.kickoffMs > now + 30 * 24 * 60 * 60 * 1000) return null
  // بعض مزوّدي البيانات يتأخرون في تغيير الحالة إلى FINAL، فلا نعرض مباراة كمباشرة بعد مدة غير منطقية.
  const elapsedMinutes = (now - parts.kickoffMs) / 60000
  const isLive = state === 'in' && elapsedMinutes >= -5 && elapsedMinutes <= 155
  if (state === 'in' && !isLive) return null
  const match: Match = {
    ...baseMatch(event, league, parts),
    round: event.week?.number ? `الجولة ${event.week.number}` : isLive ? 'مباراة مباشرة' : 'مباراة قادمة',
    score1: isLive ? scoreValue(parts.home.score) : '-', score2: isLive ? scoreValue(parts.away.score) : '-',
    isLive, minute: isLive ? status?.displayClock || '' : '',
    statusLabel: /HALFTIME/.test(statusName) ? 'استراحة' : isLive ? 'مباشر' : 'قريباً',
    isFinished: false,
  }
  return isCurrentMatch(match, now) ? match : null
}

function normalizeResult(event: ProviderEvent, league: (typeof leagueDefinitions)[number], now: number): Match | null {
  const competition = event.competitions?.[0]
  const status = competition?.status || event.status
  const statusName = status?.type?.name || ''
  if (!event.id || !competition || status?.type?.state !== 'post') return null
  if (/CANCEL|POSTPON|SUSPEND|ABANDON|ABORT|FORFEIT/.test(statusName)) return null
  const parts = readTeams(event)
  if (!parts) return null
  if (parts.kickoffMs > now || parts.kickoffMs < now - 4 * 24 * 60 * 60 * 1000) return null
  return {
    ...baseMatch(event, league, parts),
    round: event.week?.number ? `الجولة ${event.week.number}` : 'مباراة منتهية',
    score1: scoreValue(parts.home.score), score2: scoreValue(parts.away.score),
    isLive: false, minute: '',
    statusLabel: /PEN/.test(statusName) ? 'انتهت (ركلات ترجيح)' : /EXTRA|AET/.test(statusName) ? 'انتهت (وقت إضافي)' : 'انتهت',
    isFinished: true,
  }
}

async function fetchScoreboard(leagueId: string, dates: string): Promise<Scoreboard> {
  const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/${leagueId}/scoreboard?dates=${dates}&limit=400`, {
    signal: AbortSignal.timeout(8000), cache: 'no-store', headers: { Accept: 'application/json' },
  })
  if (!response.ok) throw new Error('تعذر الاتصال بمصدر المباريات')
  const data = await response.json() as Scoreboard
  if (!Array.isArray(data.events)) throw new Error('بيانات المباريات غير متاحة')
  return data
}

function dateKey(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(date)
  return ['year', 'month', 'day'].map(type => parts.find(part => part.type === type)?.value).join('')
}

function offsetDateKey(date: string, days: number) {
  const shifted = new Date(Date.UTC(Number(date.slice(0, 4)), Number(date.slice(4, 6)) - 1, Number(date.slice(6, 8)) + days))
  return shifted.toISOString().slice(0, 10).replaceAll('-', '')
}

// طلب واحد لكل دوري يغطي آخر 3 أيام (نتائج) و14 يوماً قادمة (مباريات). إن فشل نطاق التواريخ نرجع ليوم اليوم فقط.
function fetchLeagueEvents(leagueId: string, today: string) {
  const from = offsetDateKey(today, -3)
  const to = offsetDateKey(today, 14)
  return cached(`range:${leagueId}:${from}-${to}`, 45_000, async () => {
    try {
      const data = await fetchScoreboard(leagueId, `${from}-${to}`)
      return { events: data.events, partial: false }
    } catch {
      const data = await fetchScoreboard(leagueId, today)
      return { events: data.events, partial: true }
    }
  })
}

async function loadAll(timeZone: string) {
  const now = Date.now()
  const today = dateKey(new Date(now), timeZone)
  const results = await Promise.all(leagueDefinitions.map(async league => {
    try {
      const { events, partial } = await fetchLeagueEvents(league.id, today)
      return { league, events, failed: partial }
    } catch {
      return { league, events: [] as ProviderEvent[], failed: true }
    }
  }))
  return { now, results }
}

export async function loadMatchFeed(timeZone: string): Promise<MatchFeed> {
  const { now, results } = await loadAll(timeZone)
  const matches = [...new Map(results.flatMap(({ league, events }) =>
    events.map(event => normalizeMatch(event, league, now)).filter((match): match is Match => match !== null),
  ).map(match => [match.id, match])).values()]
    .filter(match => isCurrentMatch(match, Date.now()))
    .sort((first, second) => Number(second.isLive) - Number(first.isLive) || Date.parse(first.kickoff) - Date.parse(second.kickoff))
  return {
    matches, updatedAt: new Date().toISOString(),
    failedLeagues: results.filter(result => result.failed).map(result => result.league.name),
  }
}

export async function loadResultsFeed(timeZone: string): Promise<ResultsFeed> {
  const { now, results } = await loadAll(timeZone)
  const finished = [...new Map(results.flatMap(({ league, events }) =>
    events.map(event => normalizeResult(event, league, now)).filter((match): match is Match => match !== null),
  ).map(match => [match.id, match])).values()]
    .sort((first, second) => Date.parse(second.kickoff) - Date.parse(first.kickoff))
    .slice(0, 120)
  return {
    results: finished, updatedAt: new Date().toISOString(),
    failedLeagues: results.filter(result => result.failed).map(result => result.league.name),
  }
}

// ---------- تفاصيل المباراة: الإحصائيات + التشكيلات + الأحداث ----------
type SummaryStat = { name?: string; displayValue?: string }
type RosterEntry = {
  starter?: boolean
  jersey?: string
  formationPlace?: string | number
  athlete?: { displayName?: string; jersey?: string }
  position?: { abbreviation?: string; displayName?: string }
}
type SummaryRoster = { homeAway?: string; formation?: string | { summary?: string }; team?: { id?: string }; roster?: RosterEntry[] }
type SummaryEvent = {
  type?: { text?: string }
  text?: string
  shortText?: string
  clock?: { displayValue?: string }
  team?: { id?: string }
  scoringPlay?: boolean
  participants?: { athlete?: { displayName?: string } }[]
}
type Summary = {
  boxscore?: { teams?: { team?: { id?: string }; homeAway?: string; statistics?: SummaryStat[] }[] }
  rosters?: SummaryRoster[]
  keyEvents?: SummaryEvent[]
}

const statDefs: [string, string][] = [
  ['possessionPct', 'الاستحواذ'], ['totalShots', 'التسديدات'], ['shotsOnTarget', 'التسديدات على المرمى'],
  ['wonCorners', 'الركنيات'], ['foulsCommitted', 'الأخطاء'], ['offsides', 'التسلل'], ['saves', 'التصديات'],
  ['yellowCards', 'البطاقات الصفراء'], ['redCards', 'البطاقات الحمراء'], ['totalPasses', 'التمريرات'],
]

function positionGroup(abbreviation = ''): LineupPlayer['group'] {
  const code = abbreviation.toUpperCase()
  if (/^G/.test(code)) return 'gk'
  if (/^(D|CD|LB|RB|SW|WB|LWB|RWB)/.test(code)) return 'def'
  if (/^(M|CM|DM|AM|LM|RM|CAM|CDM)/.test(code)) return 'mid'
  if (/^(F|CF|ST|LF|RF|LW|RW|S)/.test(code)) return 'fwd'
  return 'other'
}

function toPlayer(entry: RosterEntry, starter: boolean): LineupPlayer | null {
  const name = entry.athlete?.displayName
  if (!name) return null
  const abbreviation = entry.position?.abbreviation || ''
  return { name, number: String(entry.jersey || entry.athlete?.jersey || ''), position: abbreviation, group: positionGroup(abbreviation), starter }
}

function readStats(summary: Summary): StatRow[] {
  const teams = summary.boxscore?.teams || []
  const home = teams.find(team => team.homeAway === 'home') || teams[0]
  const away = teams.find(team => team.homeAway === 'away') || teams[1]
  if (!home || !away) return []
  const read = (team: typeof home, key: string) => team.statistics?.find(stat => stat.name === key)?.displayValue
  const num = (value?: string) => {
    const parsed = parseFloat(String(value ?? '').replace('%', ''))
    return Number.isFinite(parsed) ? parsed : 0
  }
  return statDefs.flatMap(([key, label]) => {
    const homeRaw = read(home, key)
    const awayRaw = read(away, key)
    if (homeRaw === undefined && awayRaw === undefined) return []
    let homeValue = num(homeRaw)
    let awayValue = num(awayRaw)
    if (key === 'possessionPct') {
      if (homeValue <= 1 && awayValue <= 1) { homeValue *= 100; awayValue *= 100 }
      return [{ key, label, home: `${Math.round(homeValue)}%`, away: `${Math.round(awayValue)}%`, homeValue, awayValue }]
    }
    return [{ key, label, home: String(homeRaw ?? '0'), away: String(awayRaw ?? '0'), homeValue, awayValue }]
  })
}

function readLineup(summary: Summary, side: 'home' | 'away', index: number): TeamLineup {
  const rosters = summary.rosters || []
  const roster = rosters.find(item => item.homeAway === side) || rosters[index]
  const entries = roster?.roster || []
  const players = entries.flatMap(entry => { const player = toPlayer(entry, Boolean(entry.starter)); return player ? [player] : [] })
  const formation = typeof roster?.formation === 'string' ? roster.formation : roster?.formation?.summary || ''
  return { formation, players, source: players.some(player => player.starter) ? 'lineup' : 'none' }
}

type SquadAthlete = { displayName?: string; jersey?: string; position?: { abbreviation?: string }; items?: SquadAthlete[] }

async function loadSquad(leagueId: string, teamId: string): Promise<TeamLineup> {
  if (!/^\d{1,10}$/.test(teamId)) return { formation: '', players: [], source: 'none' }
  try {
    const data = await cached(`squad:${leagueId}:${teamId}`, 6 * 60 * 60 * 1000, async () => {
      const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/${leagueId}/teams/${teamId}/roster`, {
        signal: AbortSignal.timeout(8000), headers: { Accept: 'application/json' },
      })
      if (!response.ok) throw new Error('squad')
      return await response.json() as { athletes?: SquadAthlete[] }
    })
    const flat = (data.athletes || []).flatMap(item => item.items ?? [item])
    const players = flat.flatMap(item => {
      const player = toPlayer({ athlete: { displayName: item.displayName }, jersey: item.jersey, position: item.position }, false)
      return player ? [player] : []
    })
    return { formation: '', players, source: players.length ? 'squad' : 'none' }
  } catch {
    return { formation: '', players: [], source: 'none' }
  }
}

function readEvents(summary: Summary, homeTeamId: string): MatchEvent[] {
  return (summary.keyEvents || []).flatMap((event): MatchEvent[] => {
    const typeText = (event.type?.text || '').toLowerCase()
    const player = event.participants?.[0]?.athlete?.displayName || ''
    const minute = event.clock?.displayValue || ''
    const side: MatchEvent['side'] = event.team?.id ? (event.team.id === homeTeamId ? 'home' : 'away') : ''
    if (event.scoringPlay || /goal/.test(typeText)) {
      const label = /penalty/.test(typeText) ? 'هدف من ركلة جزاء' : /own/.test(typeText) ? 'هدف عكسي' : 'هدف'
      return [{ minute, kind: 'goal', text: `${label}${player ? ` · ${player}` : ''}`, side }]
    }
    if (/yellow/.test(typeText)) return [{ minute, kind: 'yellow', text: `بطاقة صفراء${player ? ` · ${player}` : ''}`, side }]
    if (/red/.test(typeText)) return [{ minute, kind: 'red', text: `بطاقة حمراء${player ? ` · ${player}` : ''}`, side }]
    return []
  })
}

export async function loadMatchDetails(matchId: string, teamId1: string, teamId2: string): Promise<MatchDetails> {
  const [leagueId, eventId] = matchId.split(':')
  if (!leagueDefinitions.some(league => league.id === leagueId) || !/^\d{1,12}$/.test(eventId || '')) {
    return { stats: [], home: { formation: '', players: [], source: 'none' }, away: { formation: '', players: [], source: 'none' }, events: [], updatedAt: new Date().toISOString(), error: 'مباراة غير معروفة' }
  }
  try {
    const summary = await cached(`summary:${matchId}`, 30_000, async () => {
      const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/${leagueId}/summary?event=${eventId}`, {
        signal: AbortSignal.timeout(9000), cache: 'no-store', headers: { Accept: 'application/json' },
      })
      if (!response.ok) throw new Error('summary')
      return await response.json() as Summary
    })
    let home = readLineup(summary, 'home', 0)
    let away = readLineup(summary, 'away', 1)
    // إن لم تُنشر التشكيلة الرسمية بعد نعرض قائمة لاعبي النادي كاملة
    if (home.source === 'none') home = await loadSquad(leagueId, teamId1)
    if (away.source === 'none') away = await loadSquad(leagueId, teamId2)
    return { stats: readStats(summary), home, away, events: readEvents(summary, teamId1), updatedAt: new Date().toISOString() }
  } catch {
    const [home, away] = await Promise.all([loadSquad(leagueId, teamId1), loadSquad(leagueId, teamId2)])
    return { stats: [], home, away, events: [], updatedAt: new Date().toISOString(), error: 'الإحصائيات غير متاحة لهذه المباراة حالياً' }
  }
}

type StandingStat = { name?: string; displayValue?: string; value?: number }
type StandingTeam = { displayName?: string; abbreviation?: string; logos?: { href?: string }[] }
type StandingRaw = { team?: StandingTeam; stats?: StandingStat[] }

function getStat(stats: StandingStat[] | undefined, name: string) {
  return stats?.find(s => s.name === name)?.displayValue || '0'
}

export async function loadStandings(leagueId: string): Promise<StandingsFeed> {
  const league = leagueDefinitions.find(l => l.id === leagueId)
  if (!league) {
    return { league: '', filter: '', entries: [], updatedAt: new Date().toISOString(), error: 'دوري غير معروف' }
  }
  try {
    const response = await fetch(`https://site.api.espn.com/apis/v2/sports/soccer/${leagueId}/standings`, {
      signal: AbortSignal.timeout(10000), cache: 'no-store', headers: { Accept: 'application/json' },
    })
    if (!response.ok) throw new Error('تعذر تحميل الترتيب')
    const data = await response.json() as { children?: { standings?: { entries?: StandingRaw[] } }[] }
    const entriesRaw = data.children?.[0]?.standings?.entries || []
    const entries: StandingEntry[] = entriesRaw.map((entry, index) => {
      const stats = entry.stats || []
      const teamName = entry.team?.displayName || 'فريق'
      const logo = entry.team?.logos?.[0]?.href
      return {
        rank: Number(getStat(stats, 'rank')) || index + 1,
        team: teamNames[teamName] || teamName,
        logo: logo && /^https:\/\/a\.espncdn\.com\//.test(logo) ? logo : null,
        initials: entry.team?.abbreviation || teamName.slice(0, 3),
        played: getStat(stats, 'gamesPlayed'),
        wins: getStat(stats, 'wins'),
        draws: getStat(stats, 'ties'),
        losses: getStat(stats, 'losses'),
        goalsFor: getStat(stats, 'pointsFor'),
        goalsAgainst: getStat(stats, 'pointsAgainst'),
        goalDiff: getStat(stats, 'pointDifferential'),
        points: getStat(stats, 'points'),
      }
    }).sort((a, b) => a.rank - b.rank)
    return { league: league.name, filter: league.filter, entries, updatedAt: new Date().toISOString() }
  } catch {
    return { league: league.name, filter: league.filter, entries: [], updatedAt: new Date().toISOString(), error: 'تعذر تحميل جدول الترتيب حالياً' }
  }
}
