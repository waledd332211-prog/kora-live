export const leagueDefinitions = [
  // السعودية والخليج
  { id: 'ksa.1', name: 'دوري روشن السعودي', filter: 'دوري روشن', color: 'green' },
  { id: 'uae.1', name: 'دوري أدنوك الإماراتي', filter: 'الإماراتي', color: 'red' },
  { id: 'qat.1', name: 'دوري نجوم قطر', filter: 'القطري', color: 'maroon' },
  { id: 'egy.1', name: 'الدوري المصري الممتاز', filter: 'المصري', color: 'red' },
  // أوروبا الكبرى
  { id: 'eng.1', name: 'الدوري الإنجليزي الممتاز', filter: 'البريميرليغ', color: 'violet' },
  { id: 'esp.1', name: 'الدوري الإسباني', filter: 'لا ليغا', color: 'orange' },
  { id: 'ita.1', name: 'الدوري الإيطالي', filter: 'سيري أ', color: 'blue' },
  { id: 'ger.1', name: 'الدوري الألماني', filter: 'بوندسليغا', color: 'red' },
  { id: 'fra.1', name: 'الدوري الفرنسي', filter: 'ليغ 1', color: 'cyan' },
  { id: 'ned.1', name: 'الدوري الهولندي', filter: 'إيريديفيزي', color: 'orange' },
  { id: 'por.1', name: 'الدوري البرتغالي', filter: 'البرتغالي', color: 'green' },
  { id: 'tur.1', name: 'الدوري التركي', filter: 'التركي', color: 'red' },
  { id: 'bel.1', name: 'الدوري البلجيكي', filter: 'البلجيكي', color: 'yellow' },
  { id: 'sco.1', name: 'الدوري الإسكتلندي', filter: 'الإسكتلندي', color: 'blue' },
  { id: 'gre.1', name: 'الدوري اليوناني', filter: 'اليوناني', color: 'blue' },
  { id: 'rus.1', name: 'الدوري الروسي', filter: 'الروسي', color: 'red' },
  // البطولات الأوروبية
  { id: 'uefa.champions', name: 'دوري أبطال أوروبا', filter: 'الأبطال', color: 'gold' },
  { id: 'uefa.europa', name: 'الدوري الأوروبي', filter: 'الأوروبي', color: 'amber' },
  { id: 'uefa.europa.conf', name: 'دوري المؤتمر الأوروبي', filter: 'المؤتمر', color: 'lime' },
  // أمريكا
  { id: 'usa.1', name: 'الدوري الأمريكي', filter: 'MLS', color: 'indigo' },
  { id: 'mex.1', name: 'الدوري المكسيكي', filter: 'ليغا مكس', color: 'rose' },
  { id: 'bra.1', name: 'الدوري البرازيلي', filter: 'البرازيلي', color: 'lime' },
  { id: 'arg.1', name: 'الدوري الأرجنتيني', filter: 'الأرجنتيني', color: 'sky' },
  // آسيا وأوقيانوسيا
  { id: 'afc.champions', name: 'دوري أبطال آسيا', filter: 'أبطال آسيا', color: 'gold' },
  { id: 'jpn.1', name: 'الدوري الياباني', filter: 'الياباني', color: 'red' },
  { id: 'aus.1', name: 'الدوري الأسترالي', filter: 'الأسترالي', color: 'yellow' },
] as const

export const leagues = ['الكل', ...leagueDefinitions.map(league => league.filter)]
export const defaultTimeZone = 'Asia/Riyadh'

export type Match = {
  id: string
  league: string
  filter: string
  round: string
  team1: string
  team2: string
  logo1: string | null
  logo2: string | null
  initials1: string
  initials2: string
  score1: string
  score2: string
  kickoff: string
  timeConfirmed: boolean
  channels: string[]
  isLive: boolean
  minute: string
  statusLabel: string
  leagueId: string
  eventId: string
  teamId1: string
  teamId2: string
  isFinished: boolean
}

export type ResultsFeed = {
  results: Match[]
  updatedAt: string
  failedLeagues: string[]
}

export type StatRow = { key: string; label: string; home: string; away: string; homeValue: number; awayValue: number }
export type LineupPlayer = { name: string; number: string; position: string; group: 'gk' | 'def' | 'mid' | 'fwd' | 'other'; starter: boolean }
export type TeamLineup = { formation: string; players: LineupPlayer[]; source: 'lineup' | 'squad' | 'none' }
export type MatchEvent = { minute: string; kind: 'goal' | 'yellow' | 'red' | 'other'; text: string; side: 'home' | 'away' | '' }
export type MatchDetails = {
  stats: StatRow[]
  home: TeamLineup
  away: TeamLineup
  events: MatchEvent[]
  updatedAt: string
  error?: string
}

export type MatchFeed = {
  matches: Match[]
  updatedAt: string
  failedLeagues: string[]
}

export function arabicDigits(value: string | number) {
  return String(value).replace(/[0-9]/g, digit => '٠١٢٣٤٥٦٧٨٩'[Number(digit)])
}

export function formatArabicTime(date: string, timeZone: string) {
  return new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-arab', {
    timeZone, hour: 'numeric', minute: '2-digit', hour12: true,
  }).format(new Date(date))
}

export function formatArabicDate(date: string, timeZone: string) {
  return new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-arab', {
    timeZone, weekday: 'short', day: 'numeric', month: 'long',
  }).format(new Date(date))
}

export function isCurrentMatch(match: Match, now: number) {
  const kickoff = new Date(match.kickoff).getTime()
  return match.isLive ? kickoff >= now - 4 * 60 * 60 * 1000 : kickoff >= now
}

export type StandingEntry = {
  rank: number
  team: string
  logo: string | null
  initials: string
  played: string
  wins: string
  draws: string
  losses: string
  goalsFor: string
  goalsAgainst: string
  goalDiff: string
  points: string
}

export type StandingsFeed = {
  league: string
  filter: string
  entries: StandingEntry[]
  updatedAt: string
  error?: string
}
