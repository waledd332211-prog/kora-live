// أصوات التنبيه بدون ملفات صوتية: تُولَّد عبر WebAudio.
let context: AudioContext | null = null

function ensureContext() {
  if (typeof window === 'undefined') return null
  const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
  if (!Ctor) return null
  context = context ?? new Ctor()
  return context
}

/** يجب استدعاؤها بعد أول لمسة من المستخدم (شرط iOS و Chrome). */
export function unlockAudio() {
  const ctx = ensureContext()
  if (ctx && ctx.state === 'suspended') void ctx.resume()
}

function tone(ctx: AudioContext, start: number, frequency: number, duration: number, volume = 0.25, type: OscillatorType = 'sine') {
  const oscillator = ctx.createOscillator()
  const gain = ctx.createGain()
  oscillator.type = type
  oscillator.frequency.value = frequency
  gain.gain.setValueAtTime(0.0001, start)
  gain.gain.exponentialRampToValueAtTime(volume, start + 0.02)
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration)
  oscillator.connect(gain)
  gain.connect(ctx.destination)
  oscillator.start(start)
  oscillator.stop(start + duration + 0.05)
}

export type AlertSound = 'goal' | 'soon' | 'card' | 'test'

export function playAlertSound(kind: AlertSound) {
  const ctx = ensureContext()
  if (!ctx) return
  if (ctx.state === 'suspended') void ctx.resume()
  const t = ctx.currentTime + 0.02
  if (kind === 'goal') {
    // نغمة هدف: صعود سريع ثم نغمة طويلة
    ;[523, 659, 784, 1047].forEach((f, i) => tone(ctx, t + i * 0.13, f, 0.22, 0.3, 'triangle'))
    tone(ctx, t + 0.6, 1047, 0.7, 0.3, 'triangle')
  } else if (kind === 'card') {
    tone(ctx, t, 440, 0.18, 0.28, 'square')
    tone(ctx, t + 0.25, 440, 0.18, 0.28, 'square')
  } else {
    // صافرة قبل المباراة
    tone(ctx, t, 880, 0.35, 0.28, 'sine')
    tone(ctx, t + 0.45, 880, 0.35, 0.28, 'sine')
    tone(ctx, t + 0.9, 1175, 0.6, 0.28, 'sine')
  }
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate?.(kind === 'goal' ? [200, 80, 200] : [150])
}
