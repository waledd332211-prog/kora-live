import { useEffect, useRef } from 'react'

const client = import.meta.env.VITE_ADSENSE_CLIENT as string | undefined
const slot = import.meta.env.VITE_ADSENSE_SLOT as string | undefined

declare global {
  interface Window { adsbygoogle?: unknown[] }
}

let scriptLoaded = false
function loadScript() {
  if (scriptLoaded || !client || typeof document === 'undefined') return
  scriptLoaded = true
  const script = document.createElement('script')
  script.async = true
  script.crossOrigin = 'anonymous'
  script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(client)}`
  document.head.appendChild(script)
}

/** مساحة إعلان Google AdSense. لا تظهر إذا لم يُضبط VITE_ADSENSE_CLIENT، ولا تظهر للمشتركين. */
export function AdSlot({ hidden = false, label = 'إعلان' }: { hidden?: boolean; label?: string }) {
  const ref = useRef<HTMLModElement>(null)
  const active = Boolean(client && slot && /^ca-pub-\d+$/.test(client) && !hidden)

  useEffect(() => {
    if (!active) return
    loadScript()
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}) } catch { /* ignore */ }
  }, [active])

  if (!active) return null
  return (
    <aside className="ad-slot" aria-label={label}>
      <small>{label}</small>
      <ins ref={ref} className="adsbygoogle" style={{ display: 'block' }} data-ad-client={client} data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />
    </aside>
  )
}
