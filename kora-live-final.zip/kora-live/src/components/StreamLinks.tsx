import { ExternalLink, Lock, Tv } from 'lucide-react'

export type StreamItem = { id: string; name: string; note: string; url: string | null }

type Props = { links: StreamItem[]; subscribed: boolean; loading: boolean; onSubscribe: () => void }

export function StreamLinks({ links, subscribed, loading, onSubscribe }: Props) {
  return (
    <section className="streams-section" aria-label="روابط البث">
      <div className="matches-heading"><h2>روابط البث<span>{links.length}</span></h2></div>
      <p className="streams-intro">{subscribed ? 'روابط المنصات الرسمية الناقلة. تحقق من توفر المباراة في بلدك.' : 'الروابط ظاهرة هنا لكنها مقفلة. اشترك لفتحها.'}</p>
      {loading && <div className="empty-state"><p>جارٍ تحميل الروابط…</p></div>}
      <div className="stream-list">
        {links.map(link => link.url
          ? <a key={link.id} className="stream-item" href={link.url} target="_blank" rel="noopener noreferrer nofollow"><Tv size={20} /><span><strong dir="auto">{link.name}</strong><small>{link.note}</small></span><ExternalLink size={16} /></a>
          : <button key={link.id} className="stream-item locked" onClick={onSubscribe}><Lock size={20} /><span><strong dir="auto">{link.name}</strong><small>{link.note || 'للمشتركين فقط'}</small></span><b>اشترك</b></button>)}
      </div>
      {!loading && links.length === 0 && <div className="empty-state"><p>لم تُضف روابط بعد.</p></div>}
    </section>
  )
}
