import { useEffect, useState } from 'react'
import { Goal, Square } from 'lucide-react'
import { TeamBadge } from './TeamBadge'
import { arabicDigits, formatArabicDate, formatArabicTime } from '../lib/matches'
import type { LineupPlayer, Match, MatchDetails as Details, TeamLineup } from '../lib/matches'
import { getMatchDetails } from '../server/matches.functions'

type Tab = 'stats' | 'lineup' | 'events'

const groups: { key: LineupPlayer['group']; label: string }[] = [
  { key: 'gk', label: 'حراس المرمى' }, { key: 'def', label: 'المدافعون' },
  { key: 'mid', label: 'الوسط' }, { key: 'fwd', label: 'المهاجمون' }, { key: 'other', label: 'لاعبون' },
]

function LineupColumn({ team, lineup }: { team: string; lineup: TeamLineup }) {
  const starters = lineup.players.filter(player => player.starter)
  const bench = lineup.players.filter(player => !player.starter)
  const squadMode = lineup.source === 'squad'
  const list = squadMode ? lineup.players : starters
  return (
    <div className="lineup-col">
      <h4>{team}{lineup.formation && <span className="formation">{arabicDigits(lineup.formation)}</span>}</h4>
      {lineup.source === 'none' && <p className="muted-note">لم تُنشر التشكيلة بعد.</p>}
      {squadMode && <p className="muted-note">التشكيلة الرسمية لم تُعلن بعد، وهذه قائمة لاعبي النادي.</p>}
      {groups.map(group => {
        const players = list.filter(player => player.group === group.key)
        if (!players.length) return null
        return <div className="lineup-group" key={group.key}><small>{group.label}</small>{players.map(player => <div className="player-row" key={`${player.name}${player.number}`}><b>{arabicDigits(player.number || '–')}</b><span dir="auto">{player.name}</span></div>)}</div>
      })}
      {!squadMode && bench.length > 0 && <div className="lineup-group"><small>البدلاء</small>{bench.map(player => <div className="player-row bench" key={`${player.name}${player.number}`}><b>{arabicDigits(player.number || '–')}</b><span dir="auto">{player.name}</span></div>)}</div>}
    </div>
  )
}

export function MatchDetails({ match, timeZone }: { match: Match; timeZone: string }) {
  const [tab, setTab] = useState<Tab>('stats')
  const [details, setDetails] = useState<Details | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)
    getMatchDetails({ data: { matchId: match.id, teamId1: match.teamId1, teamId2: match.teamId2 } })
      .then(data => { if (active) setDetails(data) })
      .catch(() => { if (active) setDetails({ stats: [], home: { formation: '', players: [], source: 'none' }, away: { formation: '', players: [], source: 'none' }, events: [], updatedAt: new Date().toISOString(), error: 'تعذر تحميل التفاصيل' }) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [match.id, match.teamId1, match.teamId2])

  const hasScore = match.isLive || match.isFinished
  return (
    <div className="details">
      <div className="details-head">
        <div><TeamBadge name={match.team1} logo={match.logo1} initials={match.initials1} /><strong>{match.team1}</strong></div>
        <div className="details-score">
          {hasScore ? <span dir="rtl">{arabicDigits(match.score1)} : {arabicDigits(match.score2)}</span> : <span>{match.timeConfirmed ? formatArabicTime(match.kickoff, timeZone) : '—'}</span>}
          <small>{match.isLive ? `${match.statusLabel}${match.minute ? ` · ${arabicDigits(match.minute)}` : ''}` : match.isFinished ? match.statusLabel : formatArabicDate(match.kickoff, timeZone)}</small>
        </div>
        <div><TeamBadge name={match.team2} logo={match.logo2} initials={match.initials2} /><strong>{match.team2}</strong></div>
      </div>
      <p className="details-league">{match.league}</p>
      <div className="details-tabs" role="tablist">
        {([['stats', 'الإحصائيات'], ['lineup', 'التشكيلة'], ['events', 'الأحداث']] as [Tab, string][]).map(([key, label]) => <button key={key} role="tab" aria-selected={tab === key} className={tab === key ? 'active' : ''} onClick={() => setTab(key)}>{label}</button>)}
      </div>
      {loading && <p className="muted-note center">جارٍ تحميل التفاصيل…</p>}
      {!loading && details && <>
        {details.error && <p className="muted-note center">{details.error}</p>}
        {tab === 'stats' && (details.stats.length === 0
          ? !details.error && <p className="muted-note center">لا توجد إحصائيات بعد. تظهر عند بداية المباراة.</p>
          : <div className="stat-list">{details.stats.map(row => {
            const total = row.homeValue + row.awayValue || 1
            return <div className="stat-row" key={row.key}><div className="stat-numbers"><b>{arabicDigits(row.home)}</b><span>{row.label}</span><b>{arabicDigits(row.away)}</b></div><div className="stat-bar"><i style={{ width: `${(row.homeValue / total) * 100}%` }} /><i className="away" style={{ width: `${(row.awayValue / total) * 100}%` }} /></div></div>
          })}</div>)}
        {tab === 'lineup' && <div className="lineup-grid"><LineupColumn team={match.team1} lineup={details.home} /><LineupColumn team={match.team2} lineup={details.away} /></div>}
        {tab === 'events' && (details.events.length === 0
          ? <p className="muted-note center">لا توجد أحداث مسجلة بعد.</p>
          : <ul className="event-list">{details.events.map((event, index) => <li key={index} className={event.side}>{event.kind === 'goal' ? <Goal size={16} /> : <Square size={14} fill={event.kind === 'red' ? '#e5545d' : '#f2c94c'} stroke="none" />}<span>{event.text}</span><time>{arabicDigits(event.minute)}</time></li>)}</ul>)}
      </>}
    </div>
  )
}
