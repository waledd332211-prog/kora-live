import { useCallback, useEffect, useState } from 'react'
import { LockKeyhole, LogOut, Plus, Shield, Trash2, X } from 'lucide-react'
import { api, ApiError } from '../lib/api'

type Stats = {
  visits: number; unique: number; members: number
  daily: { day: string; visits: number }[]
  subscribers: { active: number; pending: number; total: number; monthly: number; yearly: number }
  revenue: { total: number; subscriptions: number; ads: number; other: number; recent: { id: string; amount: number; source: string; note: string; date: string }[] }
}
type Sub = { ref: string; plan: 'monthly' | 'yearly'; price: number; name: string; email: string; phone: string; status: string; createdAt: number; expiresAt?: number; accessCode?: string }
type Link = { id?: string; name: string; url: string; note: string }
type Tab = 'overview' | 'subs' | 'links' | 'money' | 'settings'

const statusLabel: Record<string, string> = { pending: 'بانتظار الدفع', active: 'مفعّل', expired: 'منتهي', cancelled: 'ملغي' }
const fmt = (n: number) => new Intl.NumberFormat('ar-SA-u-nu-arab').format(n)
const fmtDate = (ms: number) => new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-arab', { dateStyle: 'medium' }).format(new Date(ms))

export function OwnerPanel({ onClose }: { onClose: () => void }) {
  const [authed, setAuthed] = useState<boolean | null>(null)
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [tab, setTab] = useState<Tab>('overview')
  const [stats, setStats] = useState<Stats | null>(null)
  const [subs, setSubs] = useState<Sub[]>([])
  const [links, setLinks] = useState<Link[]>([])
  const [instructions, setInstructions] = useState('')
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [message, setMessage] = useState('')

  const load = useCallback(async () => {
    try {
      const [s, list, l, settings] = await Promise.all([
        api<Stats>('/api/admin/stats'),
        api<{ subscribers: Sub[] }>('/api/admin/subscribers'),
        api<{ links: Link[] }>('/api/admin/links'),
        api<{ settings: { paymentInstructions?: string } }>('/api/admin/settings'),
      ])
      setStats(s); setSubs(list.subscribers); setLinks(l.links); setInstructions(settings.settings.paymentInstructions || '')
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) setAuthed(false)
    }
  }, [])

  useEffect(() => {
    api('/api/admin/me').then(() => { setAuthed(true); void load() }).catch(() => setAuthed(false))
  }, [load])

  const login = async () => {
    setBusy(true); setError('')
    try {
      await api('/api/admin/login', { password })
      setPassword(''); setAuthed(true); void load()
    } catch (e) { setError(e instanceof Error ? e.message : 'تعذر تسجيل الدخول') } finally { setBusy(false) }
  }
  const logout = async () => { await api('/api/admin/logout', {}).catch(() => undefined); onClose() }
  const flash = (text: string) => { setMessage(text); window.setTimeout(() => setMessage(''), 4000) }

  const act = async (path: string, body: unknown, done: string) => {
    try { const data = await api<{ accessCode?: string }>(path, body); flash(data.accessCode ? `${done} · رمز التفعيل: ${data.accessCode}` : done); await load() }
    catch (e) { flash(e instanceof Error ? e.message : 'فشلت العملية') }
  }

  const maxVisits = Math.max(1, ...(stats?.daily.map(d => d.visits) || [1]))

  return (
    <div className="owner-overlay" role="dialog" aria-modal="true" aria-label="لوحة المالك">
      <div className="owner-box">
        <header className="owner-head"><h2><Shield size={20} /> لوحة المالك</h2><div>{authed && <button className="owner-ghost" onClick={logout}><LogOut size={15} /> خروج</button>}<button className="icon-button" aria-label="إغلاق" onClick={onClose}><X size={18} /></button></div></header>
        {authed === null && <p className="muted-note center">جارٍ التحقق…</p>}
        {authed === false && <div className="owner-login">
          <LockKeyhole size={34} />
          <p>هذه المنطقة للمالك فقط. أدخل رمز المرور.</p>
          <input type="password" autoComplete="off" autoCapitalize="off" spellCheck={false} dir="ltr" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && password) void login() }} aria-label="رمز مرور المالك" />
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="dialog-primary" disabled={busy || !password} onClick={login}>{busy ? 'جارٍ التحقق…' : 'دخول'}</button>
        </div>}
        {authed && <>
          <nav className="owner-tabs">{([['overview', 'نظرة عامة'], ['subs', 'المشتركون'], ['links', 'روابط البث'], ['money', 'الأرباح'], ['settings', 'الإعدادات']] as [Tab, string][]).map(([key, label]) => <button key={key} className={tab === key ? 'active' : ''} onClick={() => setTab(key)}>{label}{key === 'subs' && stats && stats.subscribers.pending > 0 ? ` (${fmt(stats.subscribers.pending)})` : ''}</button>)}</nav>
          {message && <p className="owner-flash" role="status">{message}</p>}
          {tab === 'overview' && stats && <div>
            <div className="owner-cards">
              <div><small>إجمالي الزيارات</small><strong>{fmt(stats.visits)}</strong></div>
              <div><small>زوار فريدون</small><strong>{fmt(stats.unique)}</strong></div>
              <div><small>مشتركون فعّالون</small><strong>{fmt(stats.subscribers.active)}</strong></div>
              <div><small>طلبات معلّقة</small><strong>{fmt(stats.subscribers.pending)}</strong></div>
              <div><small>مسجّلون (اختياري)</small><strong>{fmt(stats.members)}</strong></div>
              <div><small>إجمالي الأرباح ﷼</small><strong>{fmt(stats.revenue.total)}</strong></div>
            </div>
            <h3>الزيارات آخر ١٤ يوماً</h3>
            <div className="owner-chart">{stats.daily.map(d => <span key={d.day} title={`${d.day}: ${d.visits}`}><i style={{ height: `${Math.max(4, (d.visits / maxVisits) * 100)}%` }} /></span>)}</div>
          </div>}
          {tab === 'subs' && <div className="owner-table-wrap">
            {subs.length === 0 && <p className="muted-note center">لا توجد طلبات اشتراك بعد.</p>}
            {subs.map(sub => <div className="owner-sub" key={sub.ref}>
              <div><strong>{sub.name}</strong><small dir="ltr">{sub.email || sub.phone}{sub.email && sub.phone ? ` · ${sub.phone}` : ''}</small><small>{sub.plan === 'yearly' ? 'سنوي' : 'شهري'} · {fmt(sub.price)} ﷼ · {fmtDate(sub.createdAt)} · مرجع <span dir="ltr">{sub.ref}</span></small>{sub.accessCode && <small>رمز التفعيل: <b dir="ltr">{sub.accessCode}</b>{sub.expiresAt ? ` · ينتهي ${fmtDate(sub.expiresAt)}` : ''}</small>}</div>
              <div className="owner-sub-actions"><span className={`pill ${sub.status}`}>{statusLabel[sub.status] || sub.status}</span>
                <button onClick={() => act('/api/admin/subscribers/activate', { ref: sub.ref }, sub.status === 'active' ? 'تم التمديد' : 'تم التفعيل')}>{sub.status === 'active' ? 'تمديد' : 'تأكيد الدفع وتفعيل'}</button>
                {sub.status === 'active' && <button className="danger" onClick={() => act('/api/admin/subscribers/deactivate', { ref: sub.ref }, 'تم الإلغاء')}>إلغاء</button>}</div>
            </div>)}
          </div>}
          {tab === 'links' && <div>
            <p className="muted-note">روابط تظهر للجميع مقفلة، وتُفتح للمشتركين فقط. استخدم روابط المنصات الرسمية المرخّصة فقط (https).</p>
            {links.map((link, i) => <div className="link-edit" key={i}>
              <input aria-label="الاسم" placeholder="الاسم" value={link.name} onChange={e => setLinks(l => l.map((x, j) => j === i ? { ...x, name: e.target.value } : x))} />
              <input aria-label="الرابط" placeholder="https://..." dir="ltr" value={link.url} onChange={e => setLinks(l => l.map((x, j) => j === i ? { ...x, url: e.target.value } : x))} />
              <input aria-label="ملاحظة" placeholder="ملاحظة (اختياري)" value={link.note} onChange={e => setLinks(l => l.map((x, j) => j === i ? { ...x, note: e.target.value } : x))} />
              <button className="icon-button" aria-label="حذف" onClick={() => setLinks(l => l.filter((_, j) => j !== i))}><Trash2 size={16} /></button>
            </div>)}
            <div className="owner-row"><button className="owner-ghost" onClick={() => setLinks(l => [...l, { name: '', url: 'https://', note: '' }])}><Plus size={15} /> إضافة رابط</button>
              <button className="dialog-primary" onClick={() => act('/api/admin/links', { links }, 'تم حفظ الروابط')}>حفظ</button></div>
          </div>}
          {tab === 'money' && stats && <div>
            <div className="owner-cards">
              <div><small>اشتراكات ﷼</small><strong>{fmt(stats.revenue.subscriptions)}</strong></div>
              <div><small>إعلانات ﷼</small><strong>{fmt(stats.revenue.ads)}</strong></div>
              <div><small>أخرى ﷼</small><strong>{fmt(stats.revenue.other)}</strong></div>
            </div>
            <p className="muted-note">أرباح الاشتراكات تُسجَّل تلقائياً عند تأكيد الدفع. أرباح الإعلانات تدخلها يدوياً من تقرير Google AdSense، وتحوّلها Google مباشرة إلى حسابك البنكي المسجّل في AdSense، لا يمكن للموقع تحويل الأموال.</p>
            <div className="owner-row"><input type="number" inputMode="decimal" min="0" placeholder="المبلغ ﷼" value={amount} onChange={e => setAmount(e.target.value)} /><input placeholder="ملاحظة" value={note} onChange={e => setNote(e.target.value)} />
              <button className="dialog-primary" disabled={!amount} onClick={async () => { await act('/api/admin/revenue', { amount: Number(amount), note, source: 'ads' }, 'تمت إضافة ربح الإعلانات'); setAmount(''); setNote('') }}>إضافة ربح إعلانات</button></div>
            <h3>آخر العمليات</h3>
            {stats.revenue.recent.map(item => <div className="owner-sub" key={item.id}><div><strong>{fmt(item.amount)} ﷼</strong><small>{item.note || item.source} · {item.date}</small></div></div>)}
          </div>}
          {tab === 'settings' && <div>
            <label className="owner-label">تعليمات الدفع (تظهر للعميل بعد طلب الاشتراك، مثل رقم الآيبان أو STC Pay)
              <textarea rows={5} value={instructions} onChange={e => setInstructions(e.target.value)} maxLength={1000} /></label>
            <button className="dialog-primary" onClick={() => act('/api/admin/settings', { paymentInstructions: instructions }, 'تم حفظ الإعدادات')}>حفظ</button>
          </div>}
        </>}
      </div>
    </div>
  )
}
