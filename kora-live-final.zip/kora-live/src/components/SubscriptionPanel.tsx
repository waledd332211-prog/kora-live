import { useState } from 'react'
import { ArrowLeft, Check, Crown, KeyRound, LogOut } from 'lucide-react'
import { api } from '../lib/api'
import { arabicDigits } from '../lib/matches'

export type SubStatus = { subscribed: boolean; plan: 'monthly' | 'yearly' | null; expiresAt: number | null }

const plans = [
  { id: 'monthly' as const, title: 'شهري', price: 15, note: 'تجديد يدوي كل شهر' },
  { id: 'yearly' as const, title: 'سنوي', price: 80, note: 'وفّر ٢٠٪ مقارنة بالشهري' },
]

type Props = { status: SubStatus; onStatus: (status: SubStatus) => void; onToast: (message: string) => void; onClose: () => void }

export function SubscriptionPanel({ status, onStatus, onToast, onClose }: Props) {
  const [step, setStep] = useState<'plans' | 'form' | 'done' | 'code'>('plans')
  const [plan, setPlan] = useState<'monthly' | 'yearly'>('yearly')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState<{ ref: string; price: number; instructions: string } | null>(null)

  const submit = async () => {
    setBusy(true); setError('')
    try {
      const data = await api<{ ref: string; price: number; instructions: string }>('/api/sub/request', { plan, name, email, phone })
      setResult(data); setStep('done')
    } catch (e) { setError(e instanceof Error ? e.message : 'تعذر إرسال الطلب') } finally { setBusy(false) }
  }

  const redeem = async () => {
    setBusy(true); setError('')
    try {
      await api('/api/sub/redeem', { code })
      const next = await api<SubStatus>('/api/sub/status')
      onStatus(next); onToast('تم تفعيل اشتراكك. روابط البث متاحة الآن'); onClose()
    } catch (e) { setError(e instanceof Error ? e.message : 'تعذر التفعيل') } finally { setBusy(false) }
  }

  const logout = async () => {
    await api('/api/sub/logout', {}).catch(() => undefined)
    onStatus({ subscribed: false, plan: null, expiresAt: null }); onToast('تم تسجيل الخروج من الاشتراك على هذا الجهاز'); onClose()
  }

  if (status.subscribed) {
    return <>
      <span className="dialog-icon"><Crown size={30} /></span>
      <h2 id="dialog-title">اشتراكك مفعّل</h2>
      <p>الباقة: {status.plan === 'yearly' ? 'سنوي' : 'شهري'}{status.expiresAt ? ` · ينتهي ${new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-arab', { dateStyle: 'long' }).format(new Date(status.expiresAt))}` : ''}</p>
      <p className="dialog-hint">تظهر لك روابط البث ولا تظهر لك الإعلانات.</p>
      <button className="dialog-secondary" onClick={logout}><LogOut size={16} /> تسجيل الخروج من الاشتراك</button>
    </>
  }

  return <>
    <span className="dialog-icon"><Crown size={30} /></span>
    <h2 id="dialog-title">اشترك في كورة لايف</h2>
    {step === 'plans' && <>
      <p>افتح روابط البث وتابع بدون إعلانات.</p>
      <div className="plan-grid">{plans.map(item => <button key={item.id} className={`plan-card ${plan === item.id ? 'selected' : ''}`} aria-pressed={plan === item.id} onClick={() => setPlan(item.id)}><strong>{item.title}</strong><b>{arabicDigits(item.price)} ﷼</b><small>{item.note}</small>{plan === item.id && <Check size={16} />}</button>)}</div>
      <button className="dialog-primary" onClick={() => setStep('form')}>متابعة <ArrowLeft size={18} /></button>
      <button className="dialog-secondary" onClick={() => { setStep('code'); setError('') }}><KeyRound size={16} /> لدي رمز تفعيل</button>
    </>}
    {step === 'form' && <>
      <p>الباقة {plan === 'yearly' ? 'السنوية ٨٠ ﷼' : 'الشهرية ١٥ ﷼'}. أدخل بياناتك ليصلك رمز التفعيل.</p>
      <div className="login-fields">
        <label>الاسم<input value={name} onChange={e => setName(e.target.value)} maxLength={60} autoComplete="name" /></label>
        <label>البريد الإلكتروني<input type="email" dir="ltr" value={email} onChange={e => setEmail(e.target.value)} maxLength={120} autoComplete="email" /></label>
        <label>أو رقم الجوال<input type="tel" dir="ltr" value={phone} onChange={e => setPhone(e.target.value)} maxLength={20} autoComplete="tel" placeholder="05xxxxxxxx" /></label>
      </div>
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="dialog-primary" disabled={busy} onClick={submit}>{busy ? 'جارٍ الإرسال…' : 'إرسال طلب الاشتراك'}</button>
      <button className="dialog-secondary" onClick={() => setStep('plans')}>رجوع</button>
    </>}
    {step === 'done' && result && <>
      <p>تم استلام طلبك. المبلغ المطلوب: <b>{arabicDigits(result.price)} ﷼</b></p>
      <div className="ref-box"><small>رقم المرجع</small><strong dir="ltr">{result.ref}</strong></div>
      <p className="pay-instructions">{result.instructions}</p>
      <p className="dialog-hint">بعد تأكيد الدفع يصلك رمز التفعيل، ثم أدخله من «لدي رمز تفعيل».</p>
      <button className="dialog-primary" onClick={() => { setStep('code'); setError('') }}>لدي رمز التفعيل</button>
    </>}
    {step === 'code' && <>
      <p>أدخل رمز التفعيل الذي أرسله لك المالك.</p>
      <div className="login-fields"><label>رمز التفعيل<input dir="ltr" value={code} onChange={e => setCode(e.target.value.toUpperCase())} maxLength={20} autoComplete="off" /></label></div>
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="dialog-primary" disabled={busy || code.length < 8} onClick={redeem}>{busy ? 'جارٍ التحقق…' : 'تفعيل الاشتراك'}</button>
      <button className="dialog-secondary" onClick={() => setStep('plans')}>رجوع</button>
    </>}
  </>
}
