# Project Guide

Kora Live (كورة لايف): Arabic RTL football site. React 19 + TanStack Start + Vite + Tailwind 4, deployed on Netlify.

## Structure
- `src/routes/index.tsx`: main UI (matches, results, standings, stream links, favorites, alerts with sound, PWA install, owner panel via `/#owner`).
- `src/server/matches.server.ts`: ESPN data (scoreboards, results, match summary: stats + lineups + events, team squads). Short in-memory cache. Women/youth teams are filtered out.
- `src/components/`: MatchCard, MatchDetails, SubscriptionPanel, StreamLinks, OwnerPanel, AdSlot.
- `netlify/functions/`: `admin.mts` (owner API), `subscribe.mts` (plans, redeem code, optional member registration), `links.mts` (stream links, URLs only returned to active subscribers), `track.mts` (visits). Data in Netlify Blobs.
- `netlify/lib/security.ts`: signed HttpOnly cookies, rate limiting, same-origin check, helpers.
- `netlify.toml`: security headers (CSP, HSTS, frame-ancestors none).

## Rules
- Never put passwords or secrets in code. `ADMIN_PASSWORD` and `SESSION_SECRET` are Netlify environment variables.
- Subscription gating is server-side only (never trust the client).
- Stream links must be official/licensed providers only.
- Single quotes, no semicolons, Arabic user-facing text.
